package com.netflix.eureka9001;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Eureka9001Application {

	public static void main(String[] args) {
		SpringApplication.run(Eureka9001Application.class, args);
	}

}
