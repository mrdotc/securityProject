package com.eudemo.eureka9002;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Eureka9002Application {

	public static void main(String[] args) {
		SpringApplication.run(Eureka9002Application.class, args);
	}

}
